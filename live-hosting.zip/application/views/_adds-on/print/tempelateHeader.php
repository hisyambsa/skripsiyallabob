<!DOCTYPE html>

<html>

<head>

	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<title></title>
	<meta name="generator" content="LibreOffice 5.4.0.3 (Linux)" />
	<meta name="author" content="ismail - [2010]" />
	<meta name="created" content="2019-02-28T00:22:09" />
	<meta name="changedby" content="Hisyam - [2010]" />
	<meta name="changed" content="2019-02-28T00:23:15" />

	<style type="text/css">
		body,
		div,
		table,
		thead,
		tbody,
		tfoot,
		tr,
		th,
		td,
		p {
			font-family: "Times new Roman";
			font-size: xx-small
		}

		a.comment-indicator:hover+comment {
			background: #ffd;
			position: absolute;
			display: block;
			border: 1px solid black;
			padding: 0.5em;
		}

		a.comment-indicator {
			background: red;
			display: inline-block;
			border: 1px solid black;
			width: 0.5em;
			height: 0.5em;
		}

		comment {
			display: none;
		}


		body {
			background: rgb(204, 204, 204);
		}

		page {
			background: white;
			display: block;
			margin: 0 auto;
			margin-bottom: 0.5cm;
			box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
		}

		page[size="A4"] {
			width: 21cm;
			height: 29.5cm;
		}

		@media print {

			body,
			page {
				margin: 0;
				box-shadow: 0;
			}
		}

		td {
			height: 14.5px;
		}
	</style>

</head>
<page size="A4">

	<div style="margin: 0.5cm">
		<br>

		<body>