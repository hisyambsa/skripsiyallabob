<div class="mx-2 pt-2">
    <div class="row">
        <div class="col text-left">
        </div>
        <div class="col text-right">
            <a class="btn btn-danger" href="https://mail.google.com/mail/u/0/#inbox/FMfcgzGpGwpvPQrBQkWhHlthJtbVGQzj?compose=new&projector=1&messagePartId=0.1" target="_blank" rel="noopener noreferrer"><i class="fas fa-envelope"></i> E-MAIL</a>
            <a class="btn btn-info" href="<?= base_url('login/logout') ?>" rel="noopener noreferrer"><i class="fas fa-sign-out-alt"></i> LOGOUT</a>
        </div>
    </div>
</div>